var AWS = require('aws-sdk');
var connect = new AWS.Connect();

exports.handler = (event) => {
    console.log('AWS Connect Start Chat Received Event: ' + JSON.stringify(event));
};